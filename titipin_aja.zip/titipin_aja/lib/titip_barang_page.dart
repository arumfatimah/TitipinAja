
import 'package:flutter/material.dart';

class TitipBarangPage extends StatefulWidget {
  const TitipBarangPage({super.key});

  @override
  State<TitipBarangPage> createState() => _TitipBarangPageState();
}

class _TitipBarangPageState extends State<TitipBarangPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController namaBarangController =
      TextEditingController();

  final TextEditingController deskripsiController =
      TextEditingController();

  String? ukuranBarang;

  @override
  void dispose() {
    namaBarangController.dispose();
    deskripsiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Titip Barang'),
        backgroundColor: const Color(0xFF1F7A5A),
        foregroundColor: Colors.white,
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),

        child: Form(
          key: _formKey,

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Formulir Penitipan',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Isi informasi barang yang ingin kamu titipkan.',
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 24),

              const Text('Nama Barang'),

              const SizedBox(height: 8),

              TextFormField(
                controller: namaBarangController,
                decoration: const InputDecoration(
                  hintText: 'Contoh: Kardus buku',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.inventory_2_outlined),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama barang harus diisi';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 20),

              const Text('Deskripsi Barang'),

              const SizedBox(height: 8),

              TextFormField(
                controller: deskripsiController,
                maxLines: 3,
                decoration: const InputDecoration(
                  hintText: 'Jelaskan barang yang ingin dititipkan',
                  border: OutlineInputBorder(),
                  alignLabelWithHint: true,
                ),
              ),

              const SizedBox(height: 20),

              const Text('Ukuran Barang'),

              const SizedBox(height: 8),

              DropdownButtonFormField<String>(
                initialValue: ukuranBarang,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.straighten),
                ),
                hint: const Text('Pilih ukuran barang'),

                items: const [
                  DropdownMenuItem(
                    value: 'S',
                    child: Text('Kecil (S)'),
                  ),
                  DropdownMenuItem(
                    value: 'M',
                    child: Text('Sedang (M)'),
                  ),
                  DropdownMenuItem(
                    value: 'L',
                    child: Text('Besar (L)'),
                  ),
                  DropdownMenuItem(
                    value: 'XL',
                    child: Text('Ekstra Besar (XL)'),
                  ),
                ],

                onChanged: (value) {
                  setState(() {
                    ukuranBarang = value;
                  });
                },

                validator: (value) {
                  if (value == null) {
                    return 'Silakan pilih ukuran barang';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 32),

              SizedBox(
                width: double.infinity,
                height: 52,

                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1F7A5A),
                    foregroundColor: Colors.white,
                  ),

                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Formulir berhasil diisi!'),
                        ),
                      );
                    }
                  },

                  child: const Text(
                    'Lanjutkan',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
